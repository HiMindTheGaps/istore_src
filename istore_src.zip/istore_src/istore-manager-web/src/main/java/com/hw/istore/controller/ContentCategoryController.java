package com.hw.istore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hw.istore.common.pojo.EasyUITreeNode;
import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.content.service.ContentCategoryService;

@Controller
@RequestMapping(value = "/content/category/")
public class ContentCategoryController {

	@Autowired
	private ContentCategoryService contentCategoryService;

	/**
	 * 查询所有内容分类信息
	 * 
	 * @param parentId
	 * @return
	 */
	@RequestMapping(value = "list")
	@ResponseBody
	public List<EasyUITreeNode> getContentCategoryList(@RequestParam(value = "id", defaultValue = "0") Long parentId) {
		return contentCategoryService.getContentCategoryList(parentId);
	}

	/**
	 * 添加一个内容分类
	 * 
	 * @param parentId
	 * @param name
	 * @return
	 */
	@RequestMapping(value = "create")
	@ResponseBody
	public TaotaoResult addContentCategory(Long parentId, String name) {
		TaotaoResult result = contentCategoryService.addCategory(parentId, name);
		return result;
	}

	/**
	 * 重命名一个分类
	 * 
	 * @param id
	 * @param name
	 */
	@RequestMapping(value = "update")
	public void updateContentCategory(Long id, String name) {
		contentCategoryService.updateCategory(id, name);
	}

	/**
	 * 删除一个分类
	 * 
	 * @param parentId
	 * @param id
	 */
	@RequestMapping(value = "delete")
	@ResponseBody
	public TaotaoResult deleteContentCategory(Long id) {
		contentCategoryService.deleteCategory(id);
		// 没有返回值导致异步请求不会调用回调函数
		return TaotaoResult.ok();
	}

}

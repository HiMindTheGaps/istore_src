package com.hw.istore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hw.istore.common.pojo.EasyUIDataGridResult;
import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.content.service.ContentService;
import com.hw.istore.pojo.TbContent;

@Controller
public class ContentController {

	@Autowired
	private ContentService contentService;

	/**
	 * 查询广告内容
	 * 
	 * @param page
	 * @param rows
	 * @param categoryId
	 * @return
	 */
	@RequestMapping("/content/query/list")
	@ResponseBody
	public EasyUIDataGridResult getContentList(int page, int rows, long categoryId) {
		EasyUIDataGridResult result = contentService.getContentList(page, rows, categoryId);
		return result;
	}

	/**
	 * 添加一个广告内容
	 * 
	 * @param content
	 * @return
	 */
	@RequestMapping("/content/save")
	@ResponseBody
	public TaotaoResult addContent(TbContent content) {
		TaotaoResult result = contentService.addContent(content);
		return result;
	}

	/**
	 * 编辑一个广告内容
	 * 
	 * @param content
	 * @return
	 */
	@RequestMapping("/rest/content/edit")
	@ResponseBody
	public TaotaoResult editContent(TbContent content) {
		TaotaoResult result = contentService.editContent(content);
		return result;
	}

	/**
	 * 删除一个广告内容
	 * 
	 * @param content
	 * @return
	 */
	@RequestMapping("/content/delete")
	@ResponseBody
	public TaotaoResult deleteContent(@RequestParam(value = "ids") long id) {
		TaotaoResult result = contentService.deleteContent(id);
		return result;
	}

}

package com.hw.istore.common.pojo;

import java.io.Serializable;
import java.util.List;

public class SearchResult implements Serializable {

	private static final long serialVersionUID = -9065719715933373442L;
	private List<SearchItem> itemList;
	private long totalPages;
	private long totalCount;

	public List<SearchItem> getItemList() {
		return itemList;
	}

	public void setItemList(List<SearchItem> itemList) {
		this.itemList = itemList;
	}

	public long getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(long totalPages) {
		this.totalPages = totalPages;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

}

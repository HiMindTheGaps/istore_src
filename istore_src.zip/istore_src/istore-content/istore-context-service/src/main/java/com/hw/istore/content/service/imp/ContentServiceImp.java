package com.hw.istore.content.service.imp;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hw.istore.common.pojo.EasyUIDataGridResult;
import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.common.util.JsonUtils;
import com.hw.istore.content.service.ContentService;
import com.hw.istore.jedis.JedisClientCluster;
import com.hw.istore.mapper.TbContentMapper;
import com.hw.istore.pojo.TbContent;
import com.hw.istore.pojo.TbContentExample;
import com.hw.istore.pojo.TbContentExample.Criteria;

@Service
public class ContentServiceImp implements ContentService {

	@Autowired
	private TbContentMapper contentMapper;

	@Autowired
	private JedisClientCluster jedisClientCluster;

	/**
	 * 分页展示广告内容
	 */
	public EasyUIDataGridResult getContentList(int page, int rows, long categoryId) {

		// 设置分页信息
		PageHelper.startPage(page, rows);
		// 设置查询条件
		TbContentExample example = new TbContentExample();
		Criteria criteria = example.createCriteria();
		criteria.andCategoryIdEqualTo(categoryId);
		// 查询
		List<TbContent> list = contentMapper.selectByExample(example);
		// 查询记录总条数
		PageInfo<TbContent> pageInfo = new PageInfo<>(list);
		long total = pageInfo.getTotal();
		// 封装EasyUIDataGridResult对象
		EasyUIDataGridResult result = new EasyUIDataGridResult();
		result.setRows(list);
		result.setTotal(total);

		return result;
	}

	/**
	 * 添加一个广告内容
	 */
	public TaotaoResult addContent(TbContent content) {

		content.setUpdated(new Date());
		content.setCreated(new Date());

		contentMapper.insert(content);

		// 缓存同步操作
		jedisClientCluster.hdel("CONTENT_KEY", content.getCategoryId().toString());

		return TaotaoResult.ok();
	}

	/**
	 * 编辑一个广告内容
	 */
	public TaotaoResult editContent(TbContent content) {
		TbContent tbContent = contentMapper.selectByPrimaryKey(content.getId());
		content.setCreated(tbContent.getCreated());
		content.setUpdated(new Date());
		contentMapper.updateByPrimaryKey(content);
		return TaotaoResult.ok();
	}

	/**
	 * 删除一个广告内容
	 */
	public TaotaoResult deleteContent(long id) {
		contentMapper.deleteByPrimaryKey(id);
		return TaotaoResult.ok();
	}

	/**
	 * 前台页面展示广告内容（包含缓存操作）
	 */
	public List<TbContent> getContentList(long categoryId) {

		// 查看缓存中是否含有所需数据
		try {
			// 缓存中有所需数据，则直接返回
			String result = jedisClientCluster.hget("CONTENT_KEY", categoryId + "");
			if (result != null && result.trim() != "") {
				List<TbContent> list_result = JsonUtils.jsonToList(result, TbContent.class);
				System.out.println("缓存中获取");
				return list_result;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 缓存中没有，数据库中查询
		// 设置查询条件
		System.out.println("数据库中获取~~~");
		TbContentExample example = new TbContentExample();
		Criteria criteria = example.createCriteria();
		criteria.andCategoryIdEqualTo(categoryId);
		// 查询
		List<TbContent> list = contentMapper.selectByExample(example);
		try {
			// 将数据库中查询到的数据添加到缓存中
			jedisClientCluster.hset("CONTENT_KEY", categoryId + "", JsonUtils.objectToJson(list));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}

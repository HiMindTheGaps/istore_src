package com.hw.istore.content.service.imp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hw.istore.common.pojo.EasyUITreeNode;
import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.content.service.ContentCategoryService;
import com.hw.istore.mapper.TbContentCategoryMapper;
import com.hw.istore.pojo.TbContentCategory;
import com.hw.istore.pojo.TbContentCategoryExample;
import com.hw.istore.pojo.TbContentCategoryExample.Criteria;

@Service
public class ContentCategoryServiceImp implements ContentCategoryService {

	@Autowired
	private TbContentCategoryMapper contentCategoryMapper;

	/**
	 * 查询内容分类列表
	 */
	public List<EasyUITreeNode> getContentCategoryList(long parentId) {

		TbContentCategoryExample example = new TbContentCategoryExample();
		Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(parentId);
		List<TbContentCategory> categorys = contentCategoryMapper.selectByExample(example);

		ArrayList<EasyUITreeNode> list = new ArrayList<EasyUITreeNode>();
		for (TbContentCategory tbContentCategory : categorys) {
			EasyUITreeNode node = new EasyUITreeNode();
			node.setId(tbContentCategory.getId());
			node.setState(tbContentCategory.getIsParent() ? "closed" : "open");
			node.setText(tbContentCategory.getName());
			list.add(node);
		}
		return list;
	}

	/**
	 * 添加一个内容分类
	 */
	public TaotaoResult addCategory(long parentId, String name) {

		TbContentCategory contentCategory = new TbContentCategory();
		contentCategory.setIsParent(false);
		contentCategory.setName(name);
		contentCategory.setParentId(parentId);
		contentCategory.setSortOrder(1);
		// 1.正常 2.删除
		contentCategory.setStatus(1);
		contentCategory.setCreated(new Date());
		contentCategory.setUpdated(new Date());

		contentCategoryMapper.insert(contentCategory);

		// 判断该节点的父节点还有没有其他节点

		TbContentCategory parentCategory = contentCategoryMapper.selectByPrimaryKey(parentId);
		if (!parentCategory.getIsParent()) {
			parentCategory.setIsParent(true);
			contentCategoryMapper.updateByPrimaryKey(parentCategory);
		}

		// 返回值中需要带入数据
		return TaotaoResult.ok(contentCategory);
	}

	/**
	 * 修改一个内容分类名称
	 */
	public void updateCategory(long id, String name) {
		TbContentCategory contentCategory = contentCategoryMapper.selectByPrimaryKey(id);
		contentCategory.setName(name);
		contentCategoryMapper.updateByPrimaryKey(contentCategory);
	}

	/**
	 * 删除一个内容分类
	 */
	public void deleteCategory(long id) {
		TbContentCategory contentCategory = contentCategoryMapper.selectByPrimaryKey(id);
		if (!contentCategory.getIsParent()) {
			// 如果是子节点，直接删除
			contentCategoryMapper.deleteByPrimaryKey(id);
		} else {
			// 如果是父节点，则获取到该父节点的各子节点并递归删除
			TbContentCategoryExample example = new TbContentCategoryExample();
			Criteria criteria = example.createCriteria();
			criteria.andParentIdEqualTo(id);
			List<TbContentCategory> list = contentCategoryMapper.selectByExample(example);
			for (TbContentCategory tbContentCategory : list) {
				deleteCategory(tbContentCategory.getId());
			}
			// 子节点全部删除后，删除该父节点
			contentCategoryMapper.deleteByPrimaryKey(id);
		}

		// 该节点递归删除成功后，判断该节点的父节点是否还有其他子节点
		TbContentCategoryExample parenteExample = new TbContentCategoryExample();
		Criteria parentCriteria = parenteExample.createCriteria();
		parentCriteria.andParentIdEqualTo(contentCategory.getParentId());
		List<TbContentCategory> parentCategorys = contentCategoryMapper.selectByExample(parenteExample);
		if (parentCategorys.isEmpty()) {
			TbContentCategory parentCategory = contentCategoryMapper.selectByPrimaryKey(contentCategory.getParentId());
			parentCategory.setIsParent(false);
			contentCategoryMapper.updateByPrimaryKey(parentCategory);
		}
	}
}

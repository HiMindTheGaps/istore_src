package com.hw.istore.content.sevice.test;

import java.util.HashSet;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hw.istore.jedis.JedisClientCluster;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

public class TestJedis {

	/*
	 * @Test public void testJedis() { Jedis jedis = new Jedis("192.168.25.129",
	 * 6379);
	 * 
	 * jedis.set("jedis", "hello, Jedis~");
	 * System.out.println(jedis.get("jedis")); jedis.close(); }
	 */

	@Test
	public void testJedisCluster() {

		HashSet<HostAndPort> nodes = new HashSet<HostAndPort>();

		nodes.add(new HostAndPort("192.168.25.129", 7001));
		nodes.add(new HostAndPort("192.168.25.129", 7002));
		nodes.add(new HostAndPort("192.168.25.129", 7003));
		nodes.add(new HostAndPort("192.168.25.129", 7004));
		nodes.add(new HostAndPort("192.168.25.129", 7005));
		nodes.add(new HostAndPort("192.168.25.129", 7006));

		JedisCluster cluster = new JedisCluster(nodes);

		cluster.set("cluster", "jedis-cluster");
		System.out.println(cluster.get("cluster"));

		cluster.close();

	}

	/*
	 * @Test public void testJedisClusterSpring() {
	 * 
	 * ApplicationContext applicationContext = new
	 * ClassPathXmlApplicationContext(
	 * "classpath:spring/applicationContext-jedis.xml");
	 * 
	 * JedisClientCluster jedisClientCluster =
	 * applicationContext.getBean(JedisClientCluster.class);
	 * 
	 * String string = jedisClientCluster.get("cluster");
	 * 
	 * System.out.println(string);
	 * 
	 * }
	 */
}

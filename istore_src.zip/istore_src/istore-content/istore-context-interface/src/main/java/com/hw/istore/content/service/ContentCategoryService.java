package com.hw.istore.content.service;

import java.util.List;

import com.hw.istore.common.pojo.EasyUITreeNode;
import com.hw.istore.common.pojo.TaotaoResult;

public interface ContentCategoryService {

	/**
	 * 查询所有内容分类
	 * 
	 * @param parentId
	 * @return
	 */
	public List<EasyUITreeNode> getContentCategoryList(long parentId);

	/**
	 * 添加一个内容分类
	 * 
	 * @param contentCategory
	 * @return
	 */
	public TaotaoResult addCategory(long parentId, String name);

	/**
	 * 修改一个内容分类名称
	 * 
	 * @param id
	 * @param name
	 * @return
	 */
	public void updateCategory(long id, String name);

	/**
	 * 删除一个内容分类
	 * 
	 * @param parentId
	 * @param id
	 */
	public void deleteCategory(long id);
}

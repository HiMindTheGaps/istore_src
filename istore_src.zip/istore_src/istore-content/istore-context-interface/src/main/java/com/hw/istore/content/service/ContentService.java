package com.hw.istore.content.service;

import java.util.List;

import com.hw.istore.common.pojo.EasyUIDataGridResult;
import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.pojo.TbContent;

public interface ContentService {

	/**
	 * 分页展示广告内容
	 * 
	 * @param page
	 * @param rows
	 * @param categoryId
	 * @return
	 */
	public EasyUIDataGridResult getContentList(int page, int rows, long categoryId);

	/**
	 * 前台页面展示广告内容
	 * 
	 * @param categoryId
	 * @return
	 */
	public List<TbContent> getContentList(long categoryId);

	/**
	 * 添加一个广告内容
	 * 
	 * @param content
	 * @return
	 */
	public TaotaoResult addContent(TbContent content);

	/**
	 * 编辑一个广告内容
	 * 
	 * @param content
	 * @return
	 */
	public TaotaoResult editContent(TbContent content);

	/**
	 * 删除一个广告内容
	 * 
	 * @param id
	 * @return
	 */
	public TaotaoResult deleteContent(long id);
}

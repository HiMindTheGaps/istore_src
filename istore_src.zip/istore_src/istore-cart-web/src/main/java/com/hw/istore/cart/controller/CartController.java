package com.hw.istore.cart.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hw.istore.common.pojo.TaotaoResult;
import com.hw.istore.common.util.CookieUtils;
import com.hw.istore.common.util.JsonUtils;
import com.hw.istore.pojo.TbItem;
import com.hw.istore.service.ItemService;

@Controller
public class CartController {

	@Autowired
	private ItemService itemService;

	/**
	 * 添加商品到购物车
	 * 
	 * @param itemId
	 * @param num
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/cart/add/{itemId}")
	public String addToCart(@PathVariable Long itemId, Integer num, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("~~~");
		// 从cookie中获取到原购物车商品列表
		List<TbItem> cartList = getCartList(request);
		boolean hasItem = false;
		for (TbItem Item : cartList) {
			// 如果原商品列表中包含该商品，则增加数量
			if (Item.getId() == itemId.longValue()) {
				Integer newNum = Item.getNum() + num;
				Item.setNum(newNum);
				hasItem = true;
				break;
			}
		}
		// 如果原商品列表中不包含该商品，则增加该商品
		if (!hasItem) {
			// 获取到该商品
			TbItem item = itemService.getById(itemId);
			// 取一张图片
			String image = item.getImage();
			if (StringUtils.isNotBlank(image)) {
				String[] images = image.split(",");
				item.setImage(images[0]);
			}
			// 设置商品数量
			item.setNum(num);
			// 将该商品添加到列表中
			cartList.add(item);
		}
		// 将新商品列表写回
		String listJson = JsonUtils.objectToJson(cartList);
		CookieUtils.setCookie(request, response, "TT_CART", listJson, 1800, true);
		return "cartSuccess";
	}

	/**
	 * 从cookie中获取到商品列表
	 * 
	 * @param request
	 * @return
	 */
	private List<TbItem> getCartList(HttpServletRequest request) {
		String cookieValue = CookieUtils.getCookieValue(request, "TT_CART", true);
		if (StringUtils.isNotBlank(cookieValue)) {
			List<TbItem> list = JsonUtils.jsonToList(cookieValue, TbItem.class);
			return list;
		}
		return new ArrayList<TbItem>();
	}

	/**
	 * 浏览购物车商品
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping("/cart/cart")
	public String showCartItem(HttpServletRequest request, Model model) {
		List<TbItem> cartList = getCartList(request);
		model.addAttribute("cartList", cartList);
		return "cart";
	}

	/**
	 * 修改购物车内商品数量
	 * 
	 * @param itemId
	 * @param num
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/cart/update/num/{itemId}/{num}")
	@ResponseBody
	public TaotaoResult updateItemNum(@PathVariable Long itemId, @PathVariable Integer num, HttpServletRequest request,
			HttpServletResponse response) {
		// 从cookie中取购物车列表
		List<TbItem> cartList = getCartList(request);
		// 查询到对应的商品
		for (TbItem tbItem : cartList) {
			if (tbItem.getId() == itemId.longValue()) {
				// 更新商品数量
				tbItem.setNum(num);
				break;
			}
		}
		// 把购车列表写入 cookie
		CookieUtils.setCookie(request, response, "TT_CART", JsonUtils.objectToJson(cartList), 1800, true);
		// 返回成功
		return TaotaoResult.ok();
	}

	/**
	 * 删除购物车中的商品
	 * 
	 * @param itemId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/cart/delete/{itemId}")
	public String deleteCartItem(@PathVariable Long itemId, HttpServletRequest request, HttpServletResponse response) {
		// 从cookie中取购物车列表
		List<TbItem> cartItemList = getCartList(request);
		// 找到对应的商品
		for (TbItem tbItem : cartItemList) {
			if (tbItem.getId() == itemId.longValue()) {
				// 删除商品
				cartItemList.remove(tbItem);
				break;
			}
		}
		// 把购车列表写入cookie
		CookieUtils.setCookie(request, response, "TT_CART", JsonUtils.objectToJson(cartItemList), 1800, true);
		// 重定向到购物车列表页面
		return "redirect:/cart/cart.html";
	}
}

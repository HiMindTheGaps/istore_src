package com.hw.istore.test.freemaker;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class TestFreemarker {
	@Test
	public void demo1() throws Exception {
		// 1.创建一个configuration对象
		Configuration configuration = new Configuration(Configuration.getVersion());
		// 2.设置模板文件所在路径
		configuration.setDirectoryForTemplateLoading(
				new File("F:/mars_workspace/istore-item-web/src/main/webapp/WEB-INF/ftl"));
		// 3.设置模板文件所使用的字符集
		configuration.setDefaultEncoding("utf-8");
		// 4.加载一个模板，创建一个模板对象
		Template template = configuration.getTemplate("hello.ftl");
		// 5.创建一个模板使用的数据集
		Map<String, String> data = new HashMap<String, String>();
		data.put("hello", "hello world!~~~~");
		// 6.创建一个writer，指定生成文件的文件名
		Writer writer = new FileWriter(new File("D:/mars_temp/hello.txt"));
		//7.调用模板对象的process方法生成文件
		template.process(data, writer);
		// 8.关闭流
		writer.close();
	}
}

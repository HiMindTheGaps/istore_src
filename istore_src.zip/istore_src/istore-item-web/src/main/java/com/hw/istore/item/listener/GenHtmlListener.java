package com.hw.istore.item.listener;

import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.hw.istore.item.pojo.Item;
import com.hw.istore.pojo.TbItem;
import com.hw.istore.pojo.TbItemDesc;
import com.hw.istore.service.ItemService;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class GenHtmlListener implements MessageListener {

	@Autowired
	private FreeMarkerConfigurer freeMarkerConfigurer;
	@Autowired
	private ItemService itemService;

	public void onMessage(Message message) {
		try {
			if (message instanceof TextMessage) {
				// 1.取出消息中的id
				TextMessage textMessage = (TextMessage) message;
				String text = textMessage.getText();
				long id = Long.parseLong(text);
				// 2.通过id从数据库中查询商品的基本信息以及商品描述
				Thread.sleep(60);
				TbItem tbItem = itemService.getById(id);
				System.out.println(id);
				Item item = new Item(tbItem);
				TbItemDesc tbItemDesc = itemService.getDescById(id);
				// 3.将商品的基本信息以及描述封装到map集合中
				Map<String, Object> data = new HashMap<String, Object>();
				data.put("item", item);
				data.put("itemDesc", tbItemDesc);
				// 4.创建freemaker模板，并生成新文件
				Configuration configuration = freeMarkerConfigurer.getConfiguration();
				Template template = configuration.getTemplate("item.ftl");
				Writer writer = new FileWriter(new File("D:/mars_temp/" + id + ".html"));
				template.process(data, writer);
				// 5.关闭流
				writer.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
